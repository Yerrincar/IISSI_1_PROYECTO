DELIMITER //
CREATE OR REPLACE PROCEDURE procAñadirProvincia (p VARCHAR(64))
	BEGIN
		INSERT INTO provincias(provincia) VALUES (p);
	END //
DELIMITER ;

DELIMITER //
CREATE OR REPLACE PROCEDURE procAñadirMunicipio (p INT, m VARCHAR(64))
	BEGIN
		INSERT INTO municipios(provinciaId ,municipio) VALUES (p, m);
	END //
DELIMITER ;

DELIMITER //
CREATE OR REPLACE PROCEDURE procAñadirDireccion (m INT, cod INT, dir VARCHAR(64))
	BEGIN
		INSERT INTO direcciones(municipioId, codigoPostal, direccion) VALUES (m, cod, dir);
	END //
DELIMITER ;

#LOS TRES SIGUIENTES PROCEDIMIENTOS TIENEN RELACIÓN CON LA RF 1.1c

DELIMITER //
CREATE OR REPLACE PROCEDURE procAñadirAficion (g VARCHAR(400))
	BEGIN
		INSERT INTO aficiones(gustos) VALUES (g);
	END //
DELIMITER ;

DELIMITER //
CREATE OR REPLACE PROCEDURE procModificarAficion(aficID INT, g VARCHAR(400))
	BEGIN
		UPDATE aficiones SET gustos = g WHERE aficionId = aficID;
	END //
DELIMITER ;

DELIMITER //
CREATE OR REPLACE PROCEDURE procEliminarAficion(aficID INT)
	BEGIN
		DELETE FROM aficiones WHERE aficionId = aficID;
	END //
DELIMITER ;

DELIMITER //
CREATE OR REPLACE PROCEDURE procAñadirUsuario (d INT, e VARCHAR(64), pass VARCHAR(100),n VARCHAR(30), a VARCHAR(30), ed SMALLINT, est DOUBLE, pes DOUBLE, sex ENUM('Hombre', 'Mujer', 'Otro'), cp VARCHAR(20))
	BEGIN
		INSERT INTO usuarios(direccionId, email, passwd, nombre, apellidos, edad, estatura, peso, sexo, colorDePelo) VALUES (d, e, pass, n, a, ed, est, pes, sex, cp);
	END //
DELIMITER ;

DELIMITER //
CREATE OR REPLACE PROCEDURE procAñadirVinculo (usu INT, fecS DATE, fecC DATE, fecD DATE, fecR DATE)
	BEGIN
		INSERT INTO vinculos(usuarioId, fechaSolicitud, fechaCreacion, fechaDesvinculacion, fechaRevocacion) VALUES (usu, fecS, fecC, fecD, fecR);
	END //
DELIMITER ;

DELIMITER //
CREATE OR REPLACE PROCEDURE procAñadirChat (vinc INT, fecC DATE, fecCierre DATE, num INT)
	BEGIN
		INSERT INTO chats(vinculoId, fechaCreacion, fechaCierre, numeroMensajes) VALUES (vinc, fecC, fecCierre, num);
	END //
DELIMITER ;

DELIMITER //
CREATE OR REPLACE PROCEDURE procAñadirMensaje (ch INT, usu INT, mens VARCHAR(1500))
	BEGIN
		INSERT INTO mensajes(chatId, usuarioId, mensaje) VALUES (ch, usu, mens);
	END //
DELIMITER ;

DELIMITER //
CREATE OR REPLACE PROCEDURE procAñadirFichaDePreferencias (usu INT, edMin INT, edMax INT, estMin DOUBLE, estMax DOUBLE, pesMin DOUBLE, pesMax DOUBLE)
	BEGIN
		INSERT INTO fichadepreferencias(usuarioId, edadMinima, edadMaxima, estaturaMinima, estaturaMaxima, pesoMinimo, pesoMaximo) VALUES (usu, edMin, edMax, estMin, estMax, pesMin, pesMax);
	END //
DELIMITER ;

# LOS TRES SIGUIENTE PROCEDIMIENTOS TIENEN RELACIÓN CON LA RF 1.1b

DELIMITER //
CREATE OR REPLACE PROCEDURE procAñadirFoto (usu INT, url VARCHAR(400), des VARCHAR(1000))
	BEGIN
		INSERT INTO fotos(usuarioId, urlFoto, descripcionFoto) VALUES (usu, url, des);
	END //
DELIMITER ;

DELIMITER //
CREATE OR REPLACE PROCEDURE procModificarFoto(fotID INT,usu INT, url VARCHAR(400), des VARCHAR(1000))
	BEGIN
		UPDATE fotos SET usuarioId = usu, urlFoto = url, descripcionFoto = des WHERE fotoId = fotID;
	END //
DELIMITER ;

DELIMITER //
CREATE OR REPLACE PROCEDURE procEliminarFoto(fotID INT)
	BEGIN
		DELETE FROM fotos WHERE fotoId = fotID;
	END //
DELIMITER ;

DELIMITER //
CREATE OR REPLACE PROCEDURE procEliminarTablas()
	BEGIN
		DELETE FROM provincias;
		DELETE FROM municipios;
		DELETE FROM direcciones;
		DELETE FROM aficiones;
		DELETE FROM usuarios;
		DELETE FROM vinculos;
		DELETE FROM chats;
		DELETE FROM mensajes;
		DELETE FROM fichadepreferencias;
		DELETE FROM fotos;
		DELETE FROM usuariosaficiones;
	END //
DELIMITER ;