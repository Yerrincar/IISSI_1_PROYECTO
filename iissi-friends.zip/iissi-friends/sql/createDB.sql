SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS provincias;
DROP TABLE IF EXISTS municipios;
DROP TABLE IF EXISTS direcciones;
DROP TABLE IF EXISTS usuarios;
DROP TABLE IF EXISTS aficiones;
DROP TABLE IF EXISTS fichadepreferencias;
DROP TABLE IF EXISTS fotos;
DROP TABLE IF EXISTS usuariosaficiones;
DROP TABLE IF EXISTS vinculos;
DROP TABLE IF EXISTS chats;
DROP TABLE IF EXISTS mensajes;

CREATE TABLE Provincias(
	provinciaId INT NOT NULL AUTO_INCREMENT,
	provincia VARCHAR(64) NOT NULL,
	PRIMARY KEY(provinciaId)
	);
	
CREATE TABLE Municipios(
	municipioId INT NOT NULL AUTO_INCREMENT,
	provinciaId INT NOT NULL,
	municipio VARCHAR(64) NOT NULL,
	PRIMARY KEY(municipioId),
	FOREIGN KEY(provinciaId) REFERENCES provincias(provinciaId) ON DELETE CASCADE
	);
	
CREATE TABLE Direcciones(
	direccionId INT NOT NULL AUTO_INCREMENT,
	municipioId INT NOT NULL,
	codigoPostal INT,
	direccion VARCHAR(64) NOT NULL,
	PRIMARY KEY(direccionId),
	FOREIGN KEY(municipioId) REFERENCES municipios(municipioId) ON DELETE CASCADE
	);
	

CREATE TABLE Aficiones(
	aficionId INT NOT NULL AUTO_INCREMENT,
	gustos VARCHAR(400),
	PRIMARY KEY(aficionId)
	);
	
CREATE TABLE Usuarios(
	usuarioId INT NOT NULL AUTO_INCREMENT,
	direccionId INT NOT NULL,
	email VARCHAR(64) NOT NULL,
	passwd VARCHAR(100) NOT NULL,
	nombre VARCHAR(30) NOT NULL,
	apellidos VARCHAR(30) NOT NULL,
	edad SMALLINT NOT NULL,
	estatura DOUBLE DEFAULT 1.74,
	peso DOUBLE DEFAULT 75.0,
	sexo ENUM('Hombre', 'Mujer', 'Otro'),
	colorDePelo VARCHAR(20) DEFAULT 'Negro',
	PRIMARY KEY(usuarioId),
	FOREIGN KEY(direccionId) REFERENCES direcciones(direccionId) ON DELETE CASCADE
	);



CREATE TABLE Vinculos(
	vinculoId INT NOT NULL AUTO_INCREMENT,
	usuarioId INT NOT NULL,
	fechaSolicitud DATE NOT NULL,
	fechaCreacion DATE,
	fechaDesvinculacion DATE,
	fechaRevocacion DATE,
	PRIMARY KEY(vinculoId),
	FOREIGN KEY(usuarioId) REFERENCES usuarios(usuarioId) ON DELETE CASCADE,
	CONSTRAINT fechaNoValida CHECK (fechaCreacion < fechaDesvinculacion),
	CONSTRAINT fechaSolicitudNoValida CHECK (fechaSolicitud < fechaCreacion),
	CONSTRAINT fechaSocitudNoValida2 CHECK (fechaSolicitud < fechaRevocacion)
	);

CREATE TABLE Chats(
	chatId INT NOT NULL AUTO_INCREMENT,
	vinculoId INT,
	fechaCreacion DATE,
	fechaCierre DATE,
	numeroMensajes INT,
	PRIMARY KEY(chatId),
	FOREIGN KEY(vinculoId) REFERENCES vinculos(vinculoId) ON DELETE CASCADE
	);

CREATE TABLE Mensajes(
	mensajeId INT NOT NULL AUTO_INCREMENT,
	chatId INT,
	usuarioId INT,
	mensaje VARCHAR(1500) NOT NULL,
	PRIMARY KEY(mensajeId),
	FOREIGN KEY(chatId) REFERENCES chats(chatId) ON DELETE CASCADE,
	FOREIGN KEY(usuarioId) REFERENCES usuarios(usuarioId) ON DELETE CASCADE
	);


CREATE TABLE FichaDePreferencias(
	fichaDePreferenciasId INT NOT NULL AUTO_INCREMENT,
	usuarioId INT NOT NULL,
	edadMinima INT,
	edadMaxima INT,
	estaturaMinima DOUBLE,
	estaturaMaxima DOUBLE,
	pesoMinimo DOUBLE,
	pesoMaximo DOUBLE,
	PRIMARY KEY(fichaDePreferenciasId),
	FOREIGN KEY(usuarioId) REFERENCES usuarios(usuarioId) ON DELETE CASCADE
	);
CREATE TABLE Fotos(
	fotoId INT NOT NULL AUTO_INCREMENT,
	usuarioId INT NOT NULL,
	urlFoto VARCHAR(400) NOT NULL,
	descripcionFoto VARCHAR(1000) NOT NULL,
	PRIMARY KEY(fotoId),
	FOREIGN KEY(usuarioId) REFERENCES usuarios(usuarioId) ON DELETE CASCADE
	);

CREATE TABLE UsuariosAficiones(
	usuarioAficionesId INT NOT NULL AUTO_INCREMENT,
	usuarioId INT NOT NULL,
	aficionId INT NOT NULL,
	UNIQUE(usuarioId, aficionId),
	PRIMARY KEY(usuarioAficionesId),
	FOREIGN KEY(usuarioId) REFERENCES usuarios(usuarioId) ON DELETE CASCADE,
	FOREIGN KEY(aficionId) REFERENCES aficiones(aficionId) ON DELETE CASCADE
	);
	
SET FOREIGN_KEY_CHECKS = 1;



