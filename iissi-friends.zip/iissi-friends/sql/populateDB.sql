INSERT INTO provincias(provincia) VALUES
	('Sevilla'),
	('Málaga'),
	('Jaén'),
	('Córdoba'),
	('Cádiz');

INSERT INTO municipios(provinciaId, municipio) VALUES
	(1, 'Alcalá del Río'),
	(2, 'Torremolinos'),
	(3, 'Úbeda'),
	(4, 'Lucena'),
	(5, 'Rota');

INSERT INTO direcciones(municipioId, codigoPostal, direccion) VALUES
	(1, 41200, 'C/Cervantes'),
	(2, 41300, 'C/Tetuán'),
	(3, 41600, 'C/Madrid'),
	(4, 42100, 'C/Sevilla'),
	(5, 43400, 'C/Portugal');

INSERT INTO aficiones(gustos) VALUES
	('Leer, jugar videojuegos, esquiar'),
	('Cantar, fútbol, pádel'),
	('Escribir, cine, sacar al perro'),
	('Esgrima, acupuntura, caligrafía'),
	('Piano, caligrafía, cocina');

INSERT INTO usuarios(direccionId, email, passwd, nombre, apellidos, edad, estatura, peso, sexo, colorDePelo) VALUES
	(1, 'david010@gmail.com', 'david341','David', 'Gutierrez Soria', 19, 1.78, 73.0, 'Hombre','Castaño'),
	(2, 'lucia37@gmail.com', 'luc219','Lucía', 'Pérez Reverte', 20, 1.60, 55.5, 'Mujer',NULL),
	(3, 'antonio@gmail.com', 'antonito31','Antonio', 'Fernández Fernández', 24, 1.85, 79.7, 'Hombre','Negro'),
	(4, 'anaperez2@gmail.com', 'anitaa2190','Ana', 'Velázquez Pérez', 31, 1.65, 57.3, 'Otro','Pelirrojo'),
	(5, 'jpbetico23@gmail.com', 'jeypi21','Juan Pablo', 'Rodríguez Atea', 18, DEFAULT, DEFAULT, 'Hombre','Rubio');


INSERT INTO vinculos(usuarioId, fechaSolicitud, fechaCreacion, fechaDesvinculacion, fechaRevocacion) VALUES
	(1, '2021-01-01', '2021-01-02', NULL, NULL),
	(1, '2020-11-20', NULL, NULL, '2020-11-21'),
	(1, '2020-12-31', '2021-01-01', '2021-03-13', NULL),
	(4, '2020-12-31', NULL, NULL, '2021-01-02'),
	(3, '2021-12-24', '2021-12-25', NULL, NULL),
	(2, '2020-12-31', '2021-01-01', '2021-02-01', NULL),
	(2, '2021-12-24', NULL, NULL, '2021-12-25'),
	(2, '2021-12-25', '2021-12-26', NULL, NULL);

INSERT INTO chats(vinculoId, fechaCreacion, fechaCierre, numeroMensajes) VALUES
	(1, '2021-01-01', NULL,500),
	(2, NULL, NULL, 0),
	(3, '2020-12-31', '2021-03-13',1000),
	(4, NULL, NULL, 0),
	(5, '2021-12-24', NULL,25);
	
INSERT INTO mensajes(chatId, usuarioId, mensaje) VALUES
	(1, 1, 'Hola, ¿qué tal?'),
	(2, 2, 'Buenas tardes'),
	(3, 3, '¿Quedamos?'),
	(4, 4, '¿Qué pasa guapa?'),
	(5, 5, '¡Feliz navidad!');
INSERT INTO fichadepreferencias(usuarioId, edadMinima, edadMaxima, estaturaMinima, estaturaMaxima, pesoMinimo, pesoMaximo) VALUES
	(1, NULL, NULL, NULL, NULL, NULL, NULL),
	(2, NULL, NULL, NULL, NULL, NULL, NULL),
	(3, NULL, NULL, NULL, NULL, NULL, NULL),
	(4, 18, 23, 1.5, 1.8, NULL, NULL),
	(5, 18, 25, 1.55, 1.70, NULL, 70);


INSERT INTO usuariosaficiones(usuarioId, aficionId) VALUES
	(1, 1),
	(2, 2),
	(3, 3),
	(4, 4),
	(5, 5);


INSERT INTO fotos(fotoId, usuarioId, urlFoto, descripcionFoto) VALUES
	(1, 1, 'https://www.iissifriends.com/url?sa=i&url=https%3A%2F%2Fwww.todocolecciodfgsdfn.net%2Fjuguetes-andfgtiguos-juegos-coleccion', '1920x1080'),
	(2, 1, 'https://www.iissifriends.com/url?sa=i&url=hdfgdttps%3A%2F%2Fwww.todocodfgdsfgleccion.net%2dfgsdfFjuguetes-antiguos-juegos-cafe', '1920x1080'),
	(3, 1, 'https://www.iissifriends.com/url?sa=i&url=https%dfgdfg3A%2F%2Fwww.todocolesfdgdccion.net%2Fjuguetes-antiggsuos', '1920x1080'),
	(4, 2, 'https://www.iissifriends.com/url?sa=i&url=https%3Adsfg%2F%2Fwww.todocoleccion.net%2Fjdfgduguetes-antiguos-pepe', '1920x1080'),
	(5, 2, 'https://www.iissifriends.com/url?sa=i&url=https%3gsdfgsdfgsA%2F%2Fwww.todocolsdgseccion', '1920x1080'),
	(6, 3, 'https://www.iissifriends.com/url?sa=i&url=https%dfgdfg3A%2F%2Fwww.toad3ocolesfdgdccion.net%2Fjuguetes-antiggsuos', '1920x1080'),
	(7, 4, 'https://www.iissifriends.com/url?sa=i&url=https%3Adsfg%2F%2Fwww.todocdoleccion.net%2Fjdfgduguetes-antiguos-pepe', '1920x1080'),
	(8, 5, 'https://www.iissifriends.com/url?sa=i&url=https%3gsdfgsdfgsA%2F%2Fwwwf.todocolsdgseccion', '1920x1080');