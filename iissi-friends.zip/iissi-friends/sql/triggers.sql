DELIMITER //
CREATE OR REPLACE TRIGGER RN_1_2_emailUnico
	BEFORE INSERT ON usuarios
	FOR EACH ROW
	BEGIN
		IF EXISTS (SELECT email FROM usuarios WHERE email = NEW.email) THEN
			SIGNAL SQLSTATE '45000' SET message_text =
			'No se puede añadir un email ya existente';
		END IF;
		END//
DELIMITER ;



DELIMITER //
CREATE OR REPLACE TRIGGER RN_1_4_limiteFotos
  BEFORE INSERT ON fotos
  FOR EACH ROW
  BEGIN
    DECLARE fotosActuales INT;
    SET fotosActuales = (SELECT COUNT(*) FROM fotos P WHERE P.usuarioId = new.usuarioId);
    IF (fotosActuales >= 6) THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Un usuario no puede tener mas de 6 fotos.';
    END IF;
  END//
DELIMITER ;

DELIMITER //
CREATE OR REPLACE TRIGGER RN_1_0b_valoresPositivos
	BEFORE INSERT ON usuarios
	FOR EACH ROW
	BEGIN
		IF (NEW.peso < 0 OR NEW.estatura < 0) THEN
			SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT =
			'Se deben poner datos positivos';
		END IF;
		END//
DELIMITER ;

DELIMITER //
CREATE OR REPLACE TRIGGER RN_1_1_mayorEdad
	BEFORE INSERT ON usuarios
	FOR EACH ROW
	BEGIN
		IF(NEW.edad < 18) THEN
			SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT =
			'Debes ser mayor de edad para registrarte';
		END IF;
		END//
DELIMITER ;

DELIMITER //
CREATE OR REPLACE TRIGGER RN_2_2_maximoSolicitudes
  BEFORE INSERT ON vinculos
  FOR EACH ROW
  BEGIN
    DECLARE vinculosActuales INT;
    SET vinculosActuales = (SELECT COUNT(*) FROM vinculos V WHERE V.usuarioId = new.usuarioId);
    IF (vinculosActuales > 5) THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Un usuario no puede envíar más de 6 solicitudes por día';
    END IF;
  END//
DELIMITER ;


