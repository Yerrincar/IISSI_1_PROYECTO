DELIMITER //
CREATE OR REPLACE FUNCTION fGestionVinculos(usuID INT) RETURNS INT
	BEGIN
	DECLARE solicitudes INT;
	SET solicitudes = (SELECT COUNT(*) FROM vinculos WHERE usuarioId = usuID);
	RETURN solicitudes;
	END //
DELIMITER ; 

